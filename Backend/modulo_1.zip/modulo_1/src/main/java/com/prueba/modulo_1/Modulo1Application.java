package com.prueba.modulo_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Modulo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Modulo1Application.class, args);
	}

}
